import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { tmdbApi, TMDBMovie, TMDBTV } from '@/lib/tmdb';
import { ThreeDMarquee } from '@/components/ui/3d-marquee';
import { MediaGrid } from '@/components/MediaGrid';
import { Button } from '@/components/ui/button';
import { ChevronRight, Play, Star, TrendingUp, Film, Tv } from 'lucide-react';
import { motion } from 'framer-motion';
import { Navbar } from '@/components/Navbar';

const Home = () => {
  const [trending, setTrending] = useState<(TMDBMovie | TMDBTV)[]>([]);
  const [popularMovies, setPopularMovies] = useState<TMDBMovie[]>([]);
  const [popularTV, setPopularTV] = useState<TMDBTV[]>([]);
  const [anime, setAnime] = useState<TMDBTV[]>([]);
  const [marqueeImages, setMarqueeImages] = useState<string[]>([]);
  const [featuredItem, setFeaturedItem] = useState<TMDBMovie | TMDBTV | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [trendingRes, moviesRes, tvRes, animeRes] = await Promise.all([
          tmdbApi.getTrending('all', 'week'),
          tmdbApi.getPopularMovies(),
          tmdbApi.getPopularTV(),
          tmdbApi.getAnime(),
        ]);

        const trendingItems = trendingRes.results || [];
        setTrending(trendingItems.slice(0, 12));
        setPopularMovies(moviesRes.results || []);
        setPopularTV(tvRes.results || []);
        setAnime(animeRes.results || []);

        const featured = trendingItems.find((item: any) => item.backdrop_path);
        setFeaturedItem(featured || trendingItems[0]);

        const images = trendingItems
          .filter((item: any) => item.poster_path)
          .slice(0, 24)
          .map((item: any) => tmdbApi.getImageUrl(item.poster_path, 'w500'));
        setMarqueeImages(images);
      } catch (error) {
        console.error('Failed to fetch data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center h-[60vh]">
          <div className="animate-spin w-10 h-10 border-4 border-primary border-t-transparent rounded-full" />
        </div>
      </div>
    );
  }

  const featuredTitle = featuredItem && ('title' in featuredItem ? featuredItem.title : (featuredItem as TMDBTV).name);
  const featuredOverview = featuredItem?.overview;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      {featuredItem && (
        <section className="relative h-[70vh] overflow-hidden">
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: `url(${tmdbApi.getImageUrl(featuredItem.backdrop_path, 'original')})`,
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
          </div>

          <div className="relative container mx-auto px-4 h-full flex items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-2xl"
            >
              <h1 className="text-4xl md:text-6xl font-bold mb-4">{featuredTitle}</h1>
              <div className="flex items-center gap-4 mb-4">
                {featuredItem.vote_average > 0 && (
                  <div className="flex items-center gap-1">
                    <Star className="w-5 h-5 text-yellow-400 fill-current" />
                    <span className="font-semibold">{featuredItem.vote_average.toFixed(1)}</span>
                  </div>
                )}
                <span className="px-2 py-1 bg-primary/20 text-primary rounded text-sm">
                  {'title' in featuredItem ? 'Film' : 'Série'}
                </span>
              </div>
              <p className="text-muted-foreground text-lg mb-6 line-clamp-3">{featuredOverview}</p>
              <div className="flex gap-4">
                <Button size="lg" className="gap-2">
                  <Play className="w-5 h-5 fill-current" />
                  Regarder
                </Button>
                <Button size="lg" variant="outline">
                  Plus d'infos
                </Button>
              </div>
            </motion.div>
          </div>
        </section>
      )}

      {/* 3D Marquee */}
      {marqueeImages.length > 0 && (
        <section className="py-16 overflow-hidden">
          <div className="container mx-auto px-4 mb-8 text-center">
            <h2 className="text-3xl font-bold">
              Découvrez notre{' '}
              <span className="bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                Catalogue
              </span>
            </h2>
            <p className="text-muted-foreground mt-2">
              Des milliers de films, séries et animes vous attendent
            </p>
          </div>
          <ThreeDMarquee images={marqueeImages} />
        </section>
      )}

      {/* Trending */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <TrendingUp className="w-6 h-6 text-primary" />
              <h2 className="text-2xl font-bold">Tendances</h2>
            </div>
            <Link to="/trending">
              <Button variant="ghost" className="gap-2">
                Voir tout <ChevronRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
          <MediaGrid items={trending} />
        </div>
      </section>

      {/* Popular Movies */}
      <section className="py-12 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <Film className="w-6 h-6 text-primary" />
              <h2 className="text-2xl font-bold">Films Populaires</h2>
            </div>
            <Link to="/movies">
              <Button variant="ghost" className="gap-2">
                Voir tout <ChevronRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
          <MediaGrid items={popularMovies.slice(0, 12)} mediaType="movie" />
        </div>
      </section>

      {/* Popular TV */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <Tv className="w-6 h-6 text-primary" />
              <h2 className="text-2xl font-bold">Séries Populaires</h2>
            </div>
            <Link to="/tv">
              <Button variant="ghost" className="gap-2">
                Voir tout <ChevronRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
          <MediaGrid items={popularTV.slice(0, 12)} mediaType="tv" />
        </div>
      </section>

      {/* Anime */}
      <section className="py-12 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <Play className="w-6 h-6 text-primary" />
              <h2 className="text-2xl font-bold">Anime</h2>
            </div>
            <Link to="/anime">
              <Button variant="ghost" className="gap-2">
                Voir tout <ChevronRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
          <MediaGrid items={anime.slice(0, 12)} mediaType="tv" />
        </div>
      </section>

      {/* Footer with Discord Button */}
      <footer className="py-12 border-t border-border">
        <div className="container mx-auto px-4 text-center text-muted-foreground space-y-6">
          <p>© 2024 CStream. Tous droits réservés.</p>
          <p className="text-sm">Données fournies par CDZ</p>

          <div className="flex justify-center">
            <a
              href="https://discord.gg/HAKFFbdZ"
              target="_blank"
              rel="noopener noreferrer"
              className="group relative p-4 rounded-2xl backdrop-blur-xl border-2 border-indigo-500/30 
                         bg-gradient-to-br from-indigo-900/40 via-black/60 to-black/80 shadow-2xl 
                         hover:shadow-indigo-500/30 hover:scale-[1.02] hover:-translate-y-1 
                         active:scale-95 transition-all duration-500 ease-out cursor-pointer 
                         hover:border-indigo-400/60 overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-indigo-400/30 to-transparent 
                              -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-out" />
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-indigo-500/10 via-indigo-400/20 to-indigo-500/10 
                              opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

              <div className="relative z-10 flex items-center gap-4">
                <div className="p-3 rounded-lg bg-gradient-to-br from-indigo-500/30 to-indigo-600/10 backdrop-blur-sm 
                                group-hover:from-indigo-400/40 group-hover:to-indigo-500/20 transition-all duration-300">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 640 512"
                    className="w-7 h-7 fill-current text-indigo-400 group-hover:text-indigo-300 transition-all duration-300 group-hover:scale-110 drop-shadow-lg"
                    aria-hidden="true"
                  >
                    <path d="M524.5 69.8a485.1 485.1 0 0 0-120.4-37.1c-1-.2-2 .3-2.5 1.2a337.5 337.5 0 0 0-14.9 30.6 447.8 447.8 0 0 0-134.4 0 309.5 309.5 0 0 0-15.1-30.6c-.5-.9-1.5-1.4-2.5-1.2A483.7 483.7 0 0 0 112 69.9c-.3.1-.6.3-.8.6C39.1 183.7 18.2 294.7 28.4 404.4c.1.5.4 1 .8 1.3A487.7 487.7 0 0 0 176 479.9c.8.2 1.6-.1 2.1-.7a348.2 348.2 0 0 0 29.9-49.5c.5-.9.1-2-.9-2.4a321.2 321.2 0 0 1-45.9-21.9 1.9 1.9 0 0 1-.2-3.1 251 251 0 0 0 9.1-7.1c.6-.5 1.4-.7 2.1-.3 96.2 43.9 200.4 43.9 295.5 0 .7-.3 1.5-.2 2.1.3 3 2.4 6 4.8 9.1 7.2.8.6 1 1.7.2 2.5a301.4 301.4 0 0 1-45.9 21.8c-1 .4-1.4 1.5-.9 2.5a391.1 391.1 0 0 0 30 48.8c.5.8 1.3 1.1 2.1.7a486 486 0 0 0 147.6-74.2c.4-.3.7-.8.8-1.3 12.3-126.8-20.5-236.9-86.9-334.5ZM222.5 337.6c-29 0-52.8-26.6-52.8-59.2s23.4-59.2 52.8-59.2c29.7 0 53.3 26.8 52.8 59.2 0 32.7-23.4 59.2-52.8 59.2Zm195.4 0c-28.9 0-52.8-26.6-52.8-59.2s23.4-59.2 52.8-59.2c29.7 0 53.3 26.8 52.8 59.2 0 32.7-23.2 59.2-52.8 59.2Z" />
                  </svg>
                </div>
                <div className="flex-1 text-left">
                  <p className="text-indigo-400 font-bold text-lg group-hover:text-indigo-300 transition-colors duration-300 drop-shadow-sm">
                    Rejoindre Discord
                  </p>
                  <p className="text-indigo-300/60 text-sm group-hover:text-indigo-200/80 transition-colors duration-300">
                    Notre communauté
                  </p>
                </div>
                <div className="opacity-40 group-hover:opacity-100 group-hover:translate-x-1 transition-all duration-300">
                  <svg viewBox="0 0 24 24" stroke="currentColor" fill="none" className="w-5 h-5 text-indigo-400" aria-hidden="true">
                    <path d="M9 5l7 7-7 7" strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" />
                  </svg>
                </div>
              </div>
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;

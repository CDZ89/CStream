import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { 
  ArrowLeft, Plus, Trash2, Edit, Users, Link as LinkIcon, Save, 
  Loader2, Settings, Shield, Search, Film, Tv, Eye, EyeOff,
  Calendar, Star, Globe, Copy, CheckCircle2, AlertCircle, Info,
  TrendingUp, Database, X, ExternalLink, BarChart3
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';

/* ============================ Types ============================ */
type MediaType = 'movie' | 'tv' | 'anime' | 'series';

interface Reader {
  id: string;
  label: string;
  url: string;
  media_type: MediaType | string;
  language: string;
  enabled: boolean;
  tmdb_id?: number | null;
  season_number?: number | null;
  episode_number?: number | null;
  order_index?: number | null;
  created_at?: string;
}

interface UserData {
  id: string;
  username: string;
  avatar_url: string | null;
  friend_code: string;
  created_at: string;
  is_admin?: boolean;
}

interface TMDBResult {
  id: number;
  media_type: 'movie' | 'tv';
  title?: string;
  name?: string;
  release_date?: string;
  first_air_date?: string;
  poster_path?: string | null;
  vote_average?: number;
  overview?: string;
}

interface TMDBSeason {
  season_number: number;
  name?: string;
  episode_count?: number;
}

/* ============================ Utilities ============================ */
const formatDate = (dateString: string) => {
  try {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dateString;
  }
};

const isValidUrl = (value: string) => {
  try {
    const u = new URL(value);
    return !!u.protocol && !!u.host;
  } catch {
    return false;
  }
};

const normalizeBaseUrl = (url: string) => {
  if (!url) return url;
  return url.endsWith('/') ? url.slice(0, -1) : url;
};

const buildFinalUrl = (
  baseUrl: string, 
  mediaType: MediaType | string, 
  season?: number | null, 
  episode?: number | null
) => {
  const base = normalizeBaseUrl(baseUrl);
  if ((mediaType === 'series' || mediaType === 'tv' || mediaType === 'anime') && (season || episode)) {
    const parts: string[] = [base];
    if (season && Number.isFinite(season)) parts.push(`season/${season}`);
    if (episode && Number.isFinite(episode)) parts.push(`episode/${episode}`);
    return parts.join('/');
  }
  return base;
};

const getMediaTypeIcon = (type: string) => {
  switch (type) {
    case 'movie': return <Film className="w-4 h-4" />;
    case 'series': return <Tv className="w-4 h-4" />;
    case 'tv': return <Tv className="w-4 h-4" />;
    case 'anime': return <Star className="w-4 h-4" />;
    default: return <Film className="w-4 h-4" />;
  }
};

const getMediaTypeLabel = (type: string) => {
  switch (type) {
    case 'movie': return 'Film';
    case 'series': return 'Série';
    case 'tv': return 'TV';
    case 'anime': return 'Anime';
    default: return type;
  }
};

const getMediaTypeColor = (type: string) => {
  switch (type) {
    case 'movie': return 'text-blue-500';
    case 'series': return 'text-purple-500';
    case 'tv': return 'text-green-500';
    case 'anime': return 'text-pink-500';
    default: return 'text-gray-500';
  }
};

/* ============================ TMDB API ============================ */
const TMDB_BASE = 'https://api.themoviedb.org/3';
const TMDB_IMG = 'https://image.tmdb.org/t/p';

const useDebounced = (value: string, delay = 400) => {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
};

const searchTMDB = async (query: string): Promise<TMDBResult[]> => {
  const key = import.meta.env.VITE_TMDB_API_KEY;
  if (!key || !query.trim()) return [];
  const url = `${TMDB_BASE}/search/multi?api_key=${key}&language=fr-FR&query=${encodeURIComponent(query)}&include_adult=false&page=1`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('TMDB search failed');
  const json = await res.json();
  return (json.results || [])
    .filter((r: any) => r.media_type === 'movie' || r.media_type === 'tv')
    .slice(0, 8)
    .map((r: any) => ({
      id: r.id,
      media_type: r.media_type,
      title: r.title,
      name: r.name,
      release_date: r.release_date,
      first_air_date: r.first_air_date,
      poster_path: r.poster_path,
      vote_average: r.vote_average,
      overview: r.overview,
    }));
};

const fetchTMDBById = async (tmdbId: number, mediaType: 'movie' | 'tv'): Promise<TMDBResult | null> => {
  const key = import.meta.env.VITE_TMDB_API_KEY;
  if (!key) return null;
  try {
    const url = `${TMDB_BASE}/${mediaType}/${tmdbId}?api_key=${key}&language=fr-FR`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const json = await res.json();
    return {
      id: json.id,
      media_type: mediaType,
      title: json.title,
      name: json.name,
      release_date: json.release_date,
      first_air_date: json.first_air_date,
      poster_path: json.poster_path,
      vote_average: json.vote_average,
      overview: json.overview,
    };
  } catch {
    return null;
  }
};

const fetchTMDBSeasons = async (tmdbId: number): Promise<TMDBSeason[]> => {
  const key = import.meta.env.VITE_TMDB_API_KEY;
  if (!key) return [];
  const url = `${TMDB_BASE}/tv/${tmdbId}?api_key=${key}&language=fr-FR`;
  const res = await fetch(url);
  if (!res.ok) return [];
  const json = await res.json();
  return (json.seasons || []).map((s: any) => ({
    season_number: s.season_number,
    name: s.name,
    episode_count: s.episode_count,
  }));
};

/* ============================ Components ============================ */
const StatsCard = ({ title, value, icon, description }: { 
  title: string; 
  value: number | string; 
  icon: JSX.Element;
  description?: string;
}) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.3 }}
  >
    <Card className="hover:shadow-lg transition-shadow border-l-4 border-l-primary">
      <CardContent className="pt-6">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <p className="text-sm text-muted-foreground mb-1 font-medium">{title}</p>
            <p className="text-3xl font-bold mb-1">{value}</p>
            {description && (
              <p className="text-xs text-muted-foreground mt-1">{description}</p>
            )}
          </div>
          <div className="p-3 rounded-full bg-primary/10 text-primary">
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  </motion.div>
);

const ReaderRow = ({
  reader,
  onEdit,
  onDelete,
  onToggle,
  onCopyUrl,
  onDuplicate,
}: {
  reader: Reader;
  onEdit: (r: Reader) => void;
  onDelete: (id: string) => void;
  onToggle: (id: string, enabled: boolean) => void;
  onCopyUrl: (url: string) => void;
  onDuplicate?: (id: string) => void;
}) => (
  <TableRow className="hover:bg-secondary/20 transition-colors group">
    <TableCell className="font-medium">
      <div className="flex items-center gap-2">
        <div className={getMediaTypeColor(reader.media_type)}>
          {getMediaTypeIcon(reader.media_type)}
        </div>
        <div>
          <div className="font-medium">{reader.label}</div>
          <div className="text-xs text-muted-foreground">
            {reader.created_at && formatDate(reader.created_at)}
          </div>
        </div>
      </div>
    </TableCell>
    <TableCell className="max-w-[300px]">
      <div className="flex items-center gap-2">
        <span className="truncate text-muted-foreground text-sm font-mono bg-secondary/50 px-2 py-1 rounded">
          {reader.url}
        </span>
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={() => onCopyUrl(reader.url)}
        >
          <Copy className="w-3 h-3" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={() => window.open(reader.url, '_blank')}
        >
          <ExternalLink className="w-3 h-3" />
        </Button>
      </div>
    </TableCell>
    <TableCell>
      <Badge variant="outline" className="capitalize gap-1">
        {getMediaTypeIcon(reader.media_type)}
        {getMediaTypeLabel(reader.media_type)}
      </Badge>
    </TableCell>
    <TableCell>
      <Badge variant="secondary" className="uppercase font-mono">
        {reader.language}
      </Badge>
    </TableCell>
    <TableCell>
      {reader.tmdb_id ? (
        <Badge variant="default" className="gap-1">
          <Database className="w-3 h-3" />
          {reader.tmdb_id}
        </Badge>
      ) : (
        <Badge variant="outline" className="text-muted-foreground gap-1">
          <AlertCircle className="w-3 h-3" />
          Non lié
        </Badge>
      )}
    </TableCell>
    <TableCell>
      {reader.season_number || reader.episode_number ? (
        <Badge variant="secondary" className="font-mono">
          {reader.season_number && `S${String(reader.season_number).padStart(2, '0')}`}
          {reader.episode_number && `E${String(reader.episode_number).padStart(2, '0')}`}
        </Badge>
      ) : (
        <span className="text-xs text-muted-foreground">—</span>
      )}
    </TableCell>
    <TableCell>
      <div className="flex items-center gap-2">
        <Switch
          checked={reader.enabled}
          onCheckedChange={(checked) => onToggle(reader.id, checked)}
        />
        {reader.enabled ? (
          <Eye className="w-4 h-4 text-green-500" />
        ) : (
          <EyeOff className="w-4 h-4 text-muted-foreground" />
        )}
      </div>
    </TableCell>
    <TableCell className="text-right">
      <div className="flex justify-end gap-1">
        {onDuplicate && (
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onDuplicate(reader.id)}
            className="h-8 w-8 hover:bg-blue-500/10 text-blue-500"
            title="Dupliquer pour un autre média"
          >
            <Copy className="w-4 h-4" />
          </Button>
        )}
        <Button
          variant="ghost"
          size="icon"
          onClick={() => onEdit(reader)}
          className="h-8 w-8 hover:bg-primary/10"
        >
          <Edit className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => onDelete(reader.id)}
          className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>
    </TableCell>
  </TableRow>
);

const UserRow = ({ userData }: { userData: UserData }) => (
  <TableRow className="hover:bg-secondary/20 transition-colors">
    <TableCell>
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-primary/50 text-white flex items-center justify-center font-bold text-lg shadow-md">
          {userData.username?.charAt(0).toUpperCase() || '?'}
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-medium">{userData.username}</span>
            {userData.is_admin && (
              <Badge variant="default" className="text-xs gap-1">
                <Shield className="w-3 h-3" />
                Admin
              </Badge>
            )}
          </div>
          <p className="text-xs text-muted-foreground font-mono">{userData.id.slice(0, 8)}...</p>
        </div>
      </div>
    </TableCell>
    <TableCell>
      <Badge variant="outline" className="font-mono">{userData.friend_code}</Badge>
    </TableCell>
    <TableCell className="text-sm text-muted-foreground">
      <div className="flex items-center gap-2">
        <Calendar className="w-3 h-3" />
        {formatDate(userData.created_at)}
      </div>
    </TableCell>
  </TableRow>
);

/* ============================ Main Component ============================ */
const Admin = () => {
  const { user, isAdmin } = useAuth();
  const navigate = useNavigate();

  const [readers, setReaders] = useState<Reader[]>([]);
  const [users, setUsers] = useState<UserData[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingReader, setEditingReader] = useState<Reader | null>(null);

  const [searchReaders, setSearchReaders] = useState('');
  const [searchUsers, setSearchUsers] = useState('');
  const [filterMediaType, setFilterMediaType] = useState<string>('all');
  const [filterEnabled, setFilterEnabled] = useState<string>('all');

  const [formData, setFormData] = useState({
    label: '',
    baseUrl: '',
    media_type: 'movie' as MediaType,
    language: 'VOSTFR',
    season: '',
    episode: '',
    enabled: true,
    tmdb_id: null as number | null,
    tmdb: null as TMDBResult | null,
  });

  const [tmdbSearchMode, setTmdbSearchMode] = useState<'search' | 'id'>('search');
  const [tmdbQuery, setTmdbQuery] = useState('');
  const [tmdbIdInput, setTmdbIdInput] = useState('');
  const [tmdbMediaTypeForId, setTmdbMediaTypeForId] = useState<'movie' | 'tv'>('movie');
  const debouncedQuery = useDebounced(tmdbQuery, 400);
  const [tmdbResults, setTmdbResults] = useState<TMDBResult[]>([]);
  const [tmdbLoading, setTmdbLoading] = useState(false);
  const [tmdbSeasons, setTmdbSeasons] = useState<TMDBSeason[]>([]);
  const [showTmdbDropdown, setShowTmdbDropdown] = useState(false);
  const tmdbRef = useRef<HTMLDivElement | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [readersRes, usersRes] = await Promise.all([
        supabase.from('readers').select('*').order('created_at', { ascending: false }),
        supabase.from('profiles').select('id, username, avatar_url, friend_code, created_at, is_admin').order('created_at', { ascending: false }),
      ]);

      if (readersRes.error) throw readersRes.error;
      if (usersRes.error) throw usersRes.error;

      setReaders((readersRes.data || []) as Reader[]);
      setUsers((usersRes.data || []) as UserData[]);
    } catch (err: any) {
      toast.error(`Erreur de chargement: ${err.message || 'inconnue'}`);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!user || !isAdmin) return;
    fetchData();
  }, [user, isAdmin, fetchData]);

  useEffect(() => {
    let mounted = true;
    const run = async () => {
      if (!debouncedQuery.trim()) {
        setTmdbResults([]);
        setTmdbLoading(false);
        return;
      }
      setTmdbLoading(true);
      try {
        const res = await searchTMDB(debouncedQuery.trim());
        if (!mounted) return;
        setTmdbResults(res);
        setShowTmdbDropdown(res.length > 0);
      } catch (err) {
        console.error(err);
        setTmdbResults([]);
      } finally {
        if (mounted) setTmdbLoading(false);
      }
    };
    run();
    return () => { mounted = false; };
  }, [debouncedQuery]);

  useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      if (tmdbRef.current && !tmdbRef.current.contains(e.target as Node)) {
        setShowTmdbDropdown(false);
      }
    };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, []);

  const stats = useMemo(() => {
    const totalReaders = readers.length;
    const readersEnabled = readers.filter((r) => r.enabled).length;
    const readersWithTmdb = readers.filter((r) => r.tmdb_id).length;
    const totalUsers = users.length;
    const adminUsers = users.filter((u) => u.is_admin).length;
    
    const movieReaders = readers.filter((r) => r.media_type === 'movie').length;
    const seriesReaders = readers.filter((r) => r.media_type === 'series' || r.media_type === 'tv').length;

    return { 
      totalReaders, readersEnabled, readersWithTmdb, totalUsers, adminUsers,
      movieReaders, seriesReaders
    };
  }, [readers, users]);

  const filteredReaders = useMemo(() => {
    const q = searchReaders.trim().toLowerCase();
    let list = readers;

    if (q) {
      list = list.filter(
        (r) =>
          r.label.toLowerCase().includes(q) ||
          r.url.toLowerCase().includes(q) ||
          r.media_type.toLowerCase().includes(q) ||
          r.language.toLowerCase().includes(q) ||
          (r.tmdb_id && String(r.tmdb_id).includes(q))
      );
    }

    if (filterMediaType !== 'all') {
      list = list.filter((r) => r.media_type === filterMediaType);
    }

    if (filterEnabled === 'enabled') {
      list = list.filter((r) => r.enabled);
    } else if (filterEnabled === 'disabled') {
      list = list.filter((r) => !r.enabled);
    }

    return list;
  }, [readers, searchReaders, filterMediaType, filterEnabled]);

  const filteredUsers = useMemo(() => {
    const q = searchUsers.trim().toLowerCase();
    return q ? users.filter((u) => u.username?.toLowerCase().includes(q) || u.friend_code?.toLowerCase().includes(q)) : users;
  }, [users, searchUsers]);

  const resetForm = () => {
    setFormData({
      label: '', baseUrl: '', media_type: 'movie', language: 'VOSTFR',
      season: '', episode: '', enabled: true, tmdb_id: null, tmdb: null,
    });
    setEditingReader(null);
    setTmdbQuery('');
    setTmdbIdInput('');
    setTmdbResults([]);
    setTmdbSeasons([]);
    setShowTmdbDropdown(false);
    setTmdbSearchMode('search');
  };

  const openCreateDialog = () => {
    resetForm();
    setDialogOpen(true);
  };

  const openEditDialog = (r: Reader) => {
    setFormData({
      label: r.label,
      baseUrl: normalizeBaseUrl(r.url.replace(/\/(season|episode)\/\d+/gi, '')),
      media_type: r.media_type as MediaType,
      language: r.language,
      season: r.season_number ? String(r.season_number) : '',
      episode: r.episode_number ? String(r.episode_number) : '',
      enabled: r.enabled,
      tmdb_id: r.tmdb_id || null,
      tmdb: null,
    });
    setEditingReader(r);
    setDialogOpen(true);

    if (r.tmdb_id && (r.media_type === 'tv' || r.media_type === 'series' || r.media_type === 'anime')) {
      fetchTMDBSeasons(r.tmdb_id).then(setTmdbSeasons).catch(() => setTmdbSeasons([]));
    }
  };

  const validateForm = () => {
    if (!formData.label.trim()) {
      toast.warning('Le nom est requis.');
      return false;
    }
    if (!formData.baseUrl.trim() || !isValidUrl(formData.baseUrl.trim())) {
      toast.warning('URL de base invalide.');
      return false;
    }
    if (!formData.tmdb_id) {
      toast.warning('Vous devez lier cette source à un média TMDB. Recherchez un film/série ou entrez un ID TMDB.');
      return false;
    }
    if (formData.season && (!/^\d+$/.test(formData.season) || Number(formData.season) < 0)) {
      toast.warning('Numéro de saison invalide.');
      return false;
    }
    if (formData.episode && (!/^\d+$/.test(formData.episode) || Number(formData.episode) < 0)) {
      toast.warning('Numéro d\'épisode invalide.');
      return false;
    }
    return true;
  };

  const upsertReader = async () => {
    if (!validateForm()) return;
    setSaving(true);
    try {
      const seasonNum = formData.season ? Number(formData.season) : null;
      const episodeNum = formData.episode ? Number(formData.episode) : null;
      const finalUrl = buildFinalUrl(formData.baseUrl.trim(), formData.media_type, seasonNum, episodeNum);

      // Vérifier si une source identique existe déjà pour un autre média
      if (!editingReader) {
        const { data: existingSources, error: checkError } = await supabase
          .from('readers')
          .select('id, label, tmdb_id')
          .eq('url', finalUrl)
          .neq('tmdb_id', formData.tmdb_id);

        if (checkError) throw checkError;

        if (existingSources && existingSources.length > 0) {
          const otherMedia = existingSources[0];
          const confirmed = confirm(
            `⚠️ Cette URL existe déjà pour un autre média (TMDB ID: ${otherMedia.tmdb_id}).\n\n` +
            `Voulez-vous quand même créer cette source pour le média actuel (TMDB ID: ${formData.tmdb_id}) ?\n\n` +
            `Note: Chaque source sera exclusive à son média.`
          );
          if (!confirmed) {
            setSaving(false);
            return;
          }
        }
      }

      const payload: any = {
        label: formData.label.trim(),
        url: finalUrl,
        media_type: formData.media_type,
        language: formData.language,
        enabled: formData.enabled,
        tmdb_id: formData.tmdb_id,
        season_number: seasonNum,
        episode_number: episodeNum,
      };

      if (editingReader) {
        // Si on change le TMDB ID d'une source existante
        if (editingReader.tmdb_id !== formData.tmdb_id) {
          const confirmed = confirm(
            `⚠️ Vous êtes sur le point de changer le média lié de cette source.\n\n` +
            `Ancien média: TMDB ID ${editingReader.tmdb_id}\n` +
            `Nouveau média: TMDB ID ${formData.tmdb_id}\n\n` +
            `Cette source ne sera plus visible pour l'ancien média. Continuer ?`
          );
          if (!confirmed) {
            setSaving(false);
            return;
          }
        }

        const { error } = await supabase.from('readers').update(payload).eq('id', editingReader.id);
        if (error) throw error;
        setReaders((prev) => prev.map((r) => (r.id === editingReader.id ? { ...r, ...payload } as Reader : r)));
        toast.success('Source mise à jour avec succès', { icon: <CheckCircle2 className="w-4 h-4" /> });
      } else {
        const { data, error } = await supabase.from('readers').insert(payload).select().single();
        if (error) throw error;
        setReaders((prev) => [data as Reader, ...prev]);
        toast.success(
          `Source ajoutée avec succès pour le média TMDB ID: ${formData.tmdb_id}`, 
          { icon: <CheckCircle2 className="w-4 h-4" /> }
        );
      }

      setDialogOpen(false);
      resetForm();
    } catch (err: any) {
      toast.error(`Erreur: ${err.message || 'inconnue'}`, { icon: <AlertCircle className="w-4 h-4" /> });
    } finally {
      setSaving(false);
    }
  };

  const deleteReader = async (id: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cette source ? Cette action est irréversible.')) return;
    setSaving(true);
    try {
      const { error } = await supabase.from('readers').delete().eq('id', id);
      if (error) throw error;
      setReaders((prev) => prev.filter((r) => r.id !== id));
      toast.success('Source supprimée avec succès', { icon: <Trash2 className="w-4 h-4" /> });
    } catch (err: any) {
      toast.error(`Suppression impossible: ${err.message || 'inconnue'}`, { icon: <AlertCircle className="w-4 h-4" /> });
    } finally {
      setSaving(false);
    }
  };

  const toggleReader = async (id: string, enabled: boolean) => {
    setReaders((prev) => prev.map((r) => (r.id === id ? { ...r, enabled } : r)));
    try {
      const { error } = await supabase.from('readers').update({ enabled }).eq('id', id);
      if (error) throw error;
      toast.success(enabled ? 'Source activée' : 'Source désactivée', {
        icon: enabled ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />,
      });
    } catch {
      setReaders((prev) => prev.map((r) => (r.id === id ? { ...r, enabled: !enabled } : r)));
      toast.error('Impossible de changer l\'état', { icon: <AlertCircle className="w-4 h-4" /> });
    }
  };

  const copyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    toast.success('URL copiée dans le presse-papier', { icon: <Copy className="w-4 h-4" /> });
  };

  const duplicateSourceForMedia = async (sourceId: string) => {
    const source = readers.find(r => r.id === sourceId);
    if (!source) return;

    // Ouvrir le dialog avec les données pré-remplies mais sans TMDB ID
    setFormData({
      label: `${source.label} (copie)`,
      baseUrl: normalizeBaseUrl(source.url.replace(/\/(season|episode)\/\d+/gi, '')),
      media_type: source.media_type as MediaType,
      language: source.language,
      season: source.season_number ? String(source.season_number) : '',
      episode: source.episode_number ? String(source.episode_number) : '',
      enabled: source.enabled,
      tmdb_id: null, // Forcer à sélectionner un nouveau média
      tmdb: null,
    });
    setEditingReader(null);
    setDialogOpen(true);
    toast.info('Sélectionnez le média pour lequel dupliquer cette source', { 
      icon: <Info className="w-4 h-4" />,
      duration: 4000 
    });
  };

  const onSelectTMDB = async (item: TMDBResult) => {
    const title = item.media_type === 'movie' ? item.title || '' : item.name || '';
    const baseUrl = formData.baseUrl || `https://streaming.example.com/${item.media_type}/${item.id}`;
    
    setFormData((f) => ({
      ...f,
      label: title,
      baseUrl,
      media_type: item.media_type === 'tv' ? 'series' : (item.media_type as MediaType),
      tmdb_id: item.id,
      tmdb: item,
    }));
    setShowTmdbDropdown(false);
    setTmdbQuery('');
    setTmdbResults([]);

    if (item.media_type === 'tv') {
      try {
        const seasons = await fetchTMDBSeasons(item.id);
        setTmdbSeasons(seasons);
      } catch {
        setTmdbSeasons([]);
      }
    } else {
      setTmdbSeasons([]);
    }
  };

  const fetchByTmdbId = async () => {
    const id = parseInt(tmdbIdInput);
    if (isNaN(id) || id <= 0) {
      toast.warning('ID TMDB invalide');
      return;
    }

    setTmdbLoading(true);
    try {
      const item = await fetchTMDBById(id, tmdbMediaTypeForId);
      if (!item) {
        toast.error('Aucun résultat trouvé pour cet ID');
        return;
      }
      await onSelectTMDB(item);
      toast.success('Film/Série trouvé !');
    } catch (err) {
      toast.error('Erreur lors de la recherche');
    } finally {
      setTmdbLoading(false);
    }
  };

  const previewUrl = useMemo(() => {
    const seasonNum = formData.season ? Number(formData.season) : null;
    const episodeNum = formData.episode ? Number(formData.episode) : null;
    return buildFinalUrl(formData.baseUrl || '', formData.media_type, seasonNum, episodeNum);
  }, [formData.baseUrl, formData.media_type, formData.season, formData.episode]);

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-10">
        <Button variant="ghost" onClick={() => navigate(-1)} className="mb-4 gap-2">
          <ArrowLeft className="w-4 h-4" /> Retour
        </Button>
        <Card className="border-destructive/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <AlertCircle className="w-5 h-5" />
              Accès refusé
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Vous devez être connecté pour accéder à cette page.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="container mx-auto px-4 py-10">
        <Button variant="ghost" onClick={() => navigate(-1)} className="mb-4 gap-2">
          <ArrowLeft className="w-4 h-4" /> Retour
        </Button>
        <Card className="border-destructive/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <Shield className="w-5 h-5" />
              Accès administrateur requis
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Vous n'avez pas les permissions nécessaires pour accéder au panneau d'administration.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-10 flex items-center justify-center min-h-[400px]">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-10 h-10 animate-spin text-primary" />
          <p className="text-muted-foreground">Chargement des données...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={() => navigate(-1)} className="gap-2">
            <ArrowLeft className="w-4 h-4" /> Retour
          </Button>
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <Settings className="w-8 h-8 text-primary" />
              Administration
            </h1>
            <p className="text-muted-foreground mt-1">
              Gérez les sources de streaming et les utilisateurs
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Sources totales"
          value={stats.totalReaders}
          icon={<Database className="w-6 h-6" />}
          description={`${stats.readersEnabled} actives`}
        />
        <StatsCard
          title="Liées à TMDB"
          value={stats.readersWithTmdb}
          icon={<Film className="w-6 h-6" />}
          description={`${Math.round((stats.readersWithTmdb / stats.totalReaders) * 100) || 0}% du total`}
        />
        <StatsCard
          title="Utilisateurs"
          value={stats.totalUsers}
          icon={<Users className="w-6 h-6" />}
          description={`${stats.adminUsers} admin(s)`}
        />
        <StatsCard
          title="Par type"
          value={`${stats.movieReaders}/${stats.seriesReaders}`}
          icon={<BarChart3 className="w-6 h-6" />}
          description="Films / Séries"
        />
      </div>

      <Tabs defaultValue="readers" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2 lg:w-[400px]">
          <TabsTrigger value="readers" className="gap-2">
            <LinkIcon className="w-4 h-4" />
            Sources ({stats.totalReaders})
          </TabsTrigger>
          <TabsTrigger value="users" className="gap-2">
            <Users className="w-4 h-4" />
            Utilisateurs ({stats.totalUsers})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="readers" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <LinkIcon className="w-5 h-5" />
                    Gestion des sources
                  </CardTitle>
                  <CardDescription className="mt-1">
                    Ajoutez, modifiez ou supprimez des sources de streaming
                  </CardDescription>
                </div>
                <Button onClick={openCreateDialog} className="gap-2">
                  <Plus className="w-4 h-4" />
                  Ajouter une source
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Rechercher par nom, URL, type..."
                    value={searchReaders}
                    onChange={(e) => setSearchReaders(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Select value={filterMediaType} onValueChange={setFilterMediaType}>
                  <SelectTrigger className="w-full sm:w-[180px]">
                    <SelectValue placeholder="Type de média" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous les types</SelectItem>
                    <SelectItem value="movie">Films</SelectItem>
                    <SelectItem value="series">Séries</SelectItem>
                    <SelectItem value="tv">TV</SelectItem>
                    <SelectItem value="anime">Anime</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={filterEnabled} onValueChange={setFilterEnabled}>
                  <SelectTrigger className="w-full sm:w-[180px]">
                    <SelectValue placeholder="État" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous</SelectItem>
                    <SelectItem value="enabled">Activées</SelectItem>
                    <SelectItem value="disabled">Désactivées</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {filteredReaders.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <Database className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p className="text-lg font-medium">Aucune source trouvée</p>
                  <p className="text-sm">Essayez de modifier vos filtres ou d'ajouter une nouvelle source</p>
                </div>
              ) : (
                <div className="rounded-md border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-secondary/50">
                        <TableHead>Nom</TableHead>
                        <TableHead>URL</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Langue</TableHead>
                        <TableHead>TMDB ID</TableHead>
                        <TableHead>S/E</TableHead>
                        <TableHead>Statut</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <AnimatePresence>
                        {filteredReaders.map((reader) => (
                          <ReaderRow
                            key={reader.id}
                            reader={reader}
                            onEdit={openEditDialog}
                            onDelete={deleteReader}
                            onToggle={toggleReader}
                            onCopyUrl={copyUrl}
                            onDuplicate={duplicateSourceForMedia}
                          />
                        ))}
                      </AnimatePresence>
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Utilisateurs inscrits
              </CardTitle>
              <CardDescription className="mt-1">
                Liste de tous les utilisateurs de la plateforme
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Rechercher par nom d'utilisateur ou code ami..."
                  value={searchUsers}
                  onChange={(e) => setSearchUsers(e.target.value)}
                  className="pl-9"
                />
              </div>

              {filteredUsers.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p className="text-lg font-medium">Aucun utilisateur trouvé</p>
                </div>
              ) : (
                <div className="rounded-md border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-secondary/50">
                        <TableHead>Utilisateur</TableHead>
                        <TableHead>Code ami</TableHead>
                        <TableHead>Inscrit le</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredUsers.map((userData) => (
                        <UserRow key={userData.id} userData={userData} />
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {editingReader ? <Edit className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
              {editingReader ? 'Modifier la source' : 'Ajouter une source'}
            </DialogTitle>
            <DialogDescription>
              {editingReader 
                ? 'Modifiez les informations de la source de streaming'
                : 'Ajoutez une nouvelle source de streaming à la base de données'}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-500/20 rounded-full">
                    <Info className="w-5 h-5 text-blue-500" />
                  </div>
                  <div>
                    <p className="font-semibold text-sm">Liaison TMDB obligatoire</p>
                    <p className="text-xs text-muted-foreground">
                      Chaque source doit être liée à un film/série spécifique
                    </p>
                  </div>
                </div>
              </div>

              <Label className="flex items-center gap-2">
                <Database className="w-4 h-4" />
                Lier à un média TMDB <span className="text-destructive">*</span>
              </Label>
              
              <Tabs value={tmdbSearchMode} onValueChange={(v) => setTmdbSearchMode(v as 'search' | 'id')} className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="search">Recherche par nom</TabsTrigger>
                  <TabsTrigger value="id">Recherche par ID</TabsTrigger>
                </TabsList>

                <TabsContent value="search" className="space-y-2">
                  <div className="relative" ref={tmdbRef}>
                    <Input
                      placeholder="Recherchez un film ou une série..."
                      value={tmdbQuery}
                      onChange={(e) => {
                        setTmdbQuery(e.target.value);
                        if (e.target.value.trim()) {
                          setShowTmdbDropdown(true);
                        }
                      }}
                      onFocus={() => tmdbResults.length > 0 && setShowTmdbDropdown(true)}
                    />
                    {tmdbLoading && (
                      <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-muted-foreground" />
                    )}

                    {showTmdbDropdown && tmdbResults.length > 0 && (
                      <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="absolute z-50 w-full mt-2 bg-popover border rounded-lg shadow-xl max-h-[400px] overflow-y-auto"
                      >
                        {tmdbResults.map((item) => (
                          <div
                            key={`${item.media_type}-${item.id}`}
                            className="flex items-start gap-3 p-3 hover:bg-accent cursor-pointer transition-colors border-b last:border-b-0"
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectTMDB(item);
                            }}
                          >
                            {item.poster_path ? (
                              <img
                                src={`${TMDB_IMG}/w92${item.poster_path}`}
                                alt=""
                                className="w-14 h-20 object-cover rounded flex-shrink-0"
                              />
                            ) : (
                              <div className="w-14 h-20 bg-secondary rounded flex items-center justify-center flex-shrink-0">
                                <Film className="w-6 h-6 text-muted-foreground" />
                              </div>
                            )}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <p className="font-semibold">
                                  {item.media_type === 'movie' ? item.title : item.name}
                                </p>
                                <Badge variant="secondary" className="text-xs">
                                  {item.media_type === 'movie' ? 'Film' : 'Série'}
                                </Badge>
                              </div>
                              <p className="text-xs text-muted-foreground mt-1">
                                {item.release_date || item.first_air_date || 'Date inconnue'}
                              </p>
                              {item.vote_average > 0 && (
                                <div className="flex items-center gap-1 mt-1">
                                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                                  <span className="text-xs font-medium">{item.vote_average.toFixed(1)}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </motion.div>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <Info className="w-3 h-3" />
                    Recherchez le titre du film ou de la série
                  </p>
                </TabsContent>

                <TabsContent value="id" className="space-y-2">
                  <div className="flex gap-2">
                    <Select value={tmdbMediaTypeForId} onValueChange={(v: 'movie' | 'tv') => setTmdbMediaTypeForId(v)}>
                      <SelectTrigger className="w-[130px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="movie">Film</SelectItem>
                        <SelectItem value="tv">Série</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input
                      type="number"
                      placeholder="ID TMDB (ex: 533535)"
                      value={tmdbIdInput}
                      onChange={(e) => setTmdbIdInput(e.target.value)}
                      className="flex-1"
                    />
                    <Button onClick={fetchByTmdbId} disabled={tmdbLoading}>
                      {tmdbLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <Info className="w-3 h-3" />
                    Entrez l'ID TMDB exact (trouvable sur themoviedb.org dans l'URL)
                  </p>
                </TabsContent>
              </Tabs>

              {formData.tmdb && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex items-start gap-3 p-4 bg-green-500/10 border border-green-500/20 rounded-lg"
                >
                  {formData.tmdb.poster_path ? (
                    <img
                      src={`${TMDB_IMG}/w92${formData.tmdb.poster_path}`}
                      alt=""
                      className="w-16 h-24 object-cover rounded flex-shrink-0"
                    />
                  ) : (
                    <div className="w-16 h-24 bg-secondary rounded flex items-center justify-center flex-shrink-0">
                      <Film className="w-8 h-8 text-muted-foreground" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                          <p className="font-semibold text-sm">Média sélectionné</p>
                        </div>
                        <p className="font-medium">
                          {formData.tmdb.media_type === 'movie' ? formData.tmdb.title : formData.tmdb.name}
                        </p>
                        <div className="flex items-center gap-2 mt-1 flex-wrap">
                          <Badge variant="outline" className="text-xs">
                            {formData.tmdb.media_type === 'movie' ? 'Film' : 'Série'}
                          </Badge>
                          <Badge variant="outline" className="text-xs font-mono">
                            ID: {formData.tmdb.id}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mt-2">
                          Cette source ne sera visible que pour ce média
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 flex-shrink-0"
                        onClick={() => {
                          setFormData((f) => ({ ...f, tmdb_id: null, tmdb: null }));
                          setTmdbSeasons([]);
                        }}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="label">
                Nom de la source <span className="text-destructive">*</span>
              </Label>
              <Input
                id="label"
                placeholder="ex: Netflix HD VOSTFR"
                value={formData.label}
                onChange={(e) => setFormData({ ...formData, label: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="baseUrl" className="flex items-center gap-2">
                <Globe className="w-4 h-4" />
                URL de base <span className="text-destructive">*</span>
              </Label>
              <Input
                id="baseUrl"
                placeholder="https://example.com/watch"
                value={formData.baseUrl}
                onChange={(e) => setFormData({ ...formData, baseUrl: e.target.value })}
              />
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <Info className="w-3 h-3" />
                L'URL de base sans les segments de saison/épisode
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="mediaType">Type de média</Label>
                <Select
                  value={formData.media_type}
                  onValueChange={(value: MediaType) => setFormData({ ...formData, media_type: value })}
                >
                  <SelectTrigger id="mediaType">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="movie">Film</SelectItem>
                    <SelectItem value="series">Série</SelectItem>
                    <SelectItem value="tv">TV</SelectItem>
                    <SelectItem value="anime">Anime</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="language">Langue</Label>
                <Select
                  value={formData.language}
                  onValueChange={(value) => setFormData({ ...formData, language: value })}
                >
                  <SelectTrigger id="language">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="VOSTFR">VOSTFR</SelectItem>
                    <SelectItem value="VF">VF</SelectItem>
                    <SelectItem value="VO">VO</SelectItem>
                    <SelectItem value="MULTI">MULTI</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {(formData.media_type === 'series' || formData.media_type === 'tv' || formData.media_type === 'anime') && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="season">Saison</Label>
                  {tmdbSeasons.length > 0 ? (
                    <Select
                      value={formData.season}
                      onValueChange={(value) => setFormData({ ...formData, season: value })}
                    >
                      <SelectTrigger id="season">
                        <SelectValue placeholder="Choisir..." />
                      </SelectTrigger>
                      <SelectContent>
                        {tmdbSeasons.map((s) => (
                          <SelectItem key={s.season_number} value={String(s.season_number)}>
                            {s.name || `Saison ${s.season_number}`}
                            {s.episode_count && ` (${s.episode_count} ép.)`}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  ) : (
                    <Input
                      id="season"
                      type="number"
                      min="0"
                      placeholder="1"
                      value={formData.season}
                      onChange={(e) => setFormData({ ...formData, season: e.target.value })}
                    />
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="episode">Épisode</Label>
                  <Input
                    id="episode"
                    type="number"
                    min="0"
                    placeholder="1"
                    value={formData.episode}
                    onChange={(e) => setFormData({ ...formData, episode: e.target.value })}
                  />
                </div>
              </div>
            )}

            <div className="flex items-center justify-between p-4 bg-secondary/30 rounded-lg">
              <div className="space-y-0.5">
                <Label className="flex items-center gap-2">
                  <Eye className="w-4 h-4" />
                  Source activée
                </Label>
                <p className="text-sm text-muted-foreground">
                  La source sera visible pour tous les utilisateurs
                </p>
              </div>
              <Switch
                checked={formData.enabled}
                onCheckedChange={(checked) => setFormData({ ...formData, enabled: checked })}
              />
            </div>

            {previewUrl && isValidUrl(previewUrl) && (
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <LinkIcon className="w-4 h-4" />
                  Aperçu de l'URL finale
                </Label>
                <div className="p-3 bg-secondary/50 rounded-lg border">
                  <code className="text-sm break-all">{previewUrl}</code>
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button
              variant="outline"
              onClick={() => {
                setDialogOpen(false);
                resetForm();
              }}
              disabled={saving}
            >
              Annuler
            </Button>
            <Button onClick={upsertReader} disabled={saving} className="gap-2">
              {saving && <Loader2 className="w-4 h-4 animate-spin" />}
              <Save className="w-4 h-4" />
              {editingReader ? 'Enregistrer' : 'Créer'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Admin;